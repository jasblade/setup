#!/bin/bash
# -.- getting sick and tired of clearing out the left over socket file when this vm locks up
if [ -e ~/.ssh/master* ];
then
	rm ~/.ssh/master* ; 
fi
