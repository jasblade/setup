#!/bin/bash
#.auto mount share directory

mount -t vboxsf vbox-share ~/shared
