#!/bin/bash
#.just gets select VG info

if [[ $EUID -ne 0 ]]; then
  echo "Root privleges are required"
else
  echo "Getting volume group info..."
  vgdisplay | sed -e '/VG Name/b' -e '/VG Size/b' -e '/Free/b' -e d tee -a /tmp/vginfo.tmp 

  echo "Copy-paste this next line once back on your home system to retrieve."
  echo "scp a.jmblade@${HOSTNAME}:/tmp/vginfo.tmp ./"  
fi
