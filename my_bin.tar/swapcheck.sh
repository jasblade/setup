#!/bin/bash
#.This script will monitor swap space every second until exited with a ctrl+c trap
#.28 Jul 10 - J.Blade

trap ctrl_c INT

function ctrl_c() {
  clear;
  echo "Exiting monitoring";
  exit
}

gblPercNum=0 


black='\e[1;30m'
red='\e[1;31m'
green='\e[1;32m'
yellow='\e[1;33m'
blue='\e[1;34m'
magenta='\e[1;35m'
cyan='\e[1;36m'
white='\e[1;37m'
CLEAR='\e[0m' 


if [[ -z $1 ]]; then
  argm="Swap" 
  echo "Setting default: Swap"
else
  if [[ "$1" == *wap ]]; then
    argm="Swap"
  else
    argm="Mem:"
  fi
fi

if [[ -z $2 ]]; then
  argp="50" 
  echo "Setting default: 50%"
else
  argp="$2"
fi


function chk_percent() {
  numa=`free | grep $argm | awk '{ print $2 }'`
  numb=`free | grep $argm | awk '{ print $3 }'`
  perc=$(echo "scale=3; (${numb}/${numa})*100" | bc -l)
  percent="$(echo $perc | sed 's/\.[0-9]*//')"
}


chk_percent 

while [ 0 -ne 1 ]; do
  chk_percent 

  if [[ $percent -ge $argp ]]; then
    perc="${red}${perc}% WARNING! ${CLEAR}"
  else
    perc="${cyan}${perc}%${CLEAR}"
  fi

  if [[ $percent -ne $gblPercNum ]]; then 
          clear
          echo -e "Monitoring ${green}`hostname`${CLEAR} @ `date | awk '{ print $4 }'`"
	  echo -ne "${white}$argm Free:${CLEAR} ${cyan}`free | grep Swap | awk '{ print $4 }'`${CLEAR}" ;
	  echo " " ;
	  echo -ne "${white}$argm Used:${CLEAR} ${perc}";
	  echo " " ;
	  echo "ctrl+c to exit"
 	  gblPercNum="$percent" 
  fi

  sleep 1 ;
done
